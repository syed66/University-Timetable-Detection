class Module(var year: Int, var term: Int, var activitiesList: Array<Activity>) {

}