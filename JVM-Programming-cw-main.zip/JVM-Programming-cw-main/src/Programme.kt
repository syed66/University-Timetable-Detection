class Programme(var name: String, var type: Int, var modules: Array<Module> = emptyArray()) {

}