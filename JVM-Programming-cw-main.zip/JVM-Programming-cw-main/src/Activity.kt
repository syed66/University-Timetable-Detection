class Activity(var day: Int, var time: Int, var duration: Int, var type: Int, var optionality: Int) {


}