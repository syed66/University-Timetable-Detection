
class saveData{
    fun addProgrammeData(name : String, type: String, years: String){

    }
    fun editProgrammeData(name: String, changeName: String, changeType: String,changeYears: String){

    }
    fun deleteProgrammeData(name: String){

    }

    fun addModuleData(name: String, programme: String, years: String, term: String, year: String){

    }
    fun editModuleData(name: String, changeName: String, changeProgramme: String, changeYear: String, changeTerm: String){

    }
    fun deleteModuleData(name: String){

    }

    fun addActivitesData(name: String, module: String, day: String, time: String, changeDuration: String,optionality: String){

    }
    fun editActivitesData(name: String, changeType: String, changeModule: String, changeDay: String, changeTime: String,changeDuration: String){

    }
    fun deleteActivitesData(name: String){

    }
}